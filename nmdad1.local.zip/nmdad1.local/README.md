
    Projectnaam: Dog Date
    Voornaam en familienaam: Jodie De Greef
    Opleidingsonderdeel: NMDAD I
    Academiejaar: 2016-2017
    Opleiding: Bachelor in de grafische en digitale media
    Afstudeerrichting: Multimediaproductie
    Keuzeoptie: Produce
    Opleidingsinstelling: Arteveldehogeschool
