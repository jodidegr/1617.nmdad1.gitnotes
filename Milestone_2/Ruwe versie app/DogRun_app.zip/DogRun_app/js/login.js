/* niet aangemeld? ga naar login?! */





var count = 2;
function validate() {
var un = document.myform.username.value;
var pw = document.myform.pword.value;
var valid = false;
var unArray = ["jodie", "niel", "username3", "username4"];  
var pwArray = ["jodie", "niel", "password3", "password4"]; 

for (var i=0; i <unArray.length; i++) {
if ((un == unArray[i]) && (pw == pwArray[i])) {
valid = true;
break;
}
}
if (valid) {
alert ("Login was sucessfully processed.  You will be redirected to the home page.");
window.location = "../index.html";
return false;
}else{
   alert("Error Password or Username")
  }
}




/* Gegevens aanpassen aan gebruiker */
function loginActief(){
    if (unArray == "jodie" && pwArray == "jodie"){
            document.getElementById("firstNameP").innerHTML = objPeopleProfile[1].firstName;
            document.getElementById("nameP").innerHTML = objPeopleProfile[1].Name;
            document.getElementById("addressP").innerHTML = objPeopleProfile[1].address;
            document.getElementById("sexP").innerHTML = objPeopleProfile[1].sex;
            document.getElementById("emailP").innerHTML = objPeopleProfile[1].email;
    }else{
        window.location = "login.html"
    }
}




/* INFORMATIE USERS */

var objPeopleProfile = [
	{ 
		userid: "Niel",
		firstName: "Niel",
        Name: "Duquesne",
        address: "239 North Halifax Court Fishers, IN 46037",
        sex: "Male",
        email: "nielduquesne@gmail.com"
	},
	{ 
		userid: "Jodie",
		firstName: "Jodie",
        Name: "De Greef",
        address: "258 North Halifax Court Fishers, IN 46037",
        sex: "Female",
        email: "jodiedegreef@gmail.com"
	},

]

/*


document.getElementById("firstNameP").innerHTML = objPeopleProfile[0].firstName;
document.getElementById("nameP").innerHTML = objPeopleProfile[0].Name;
document.getElementById("addressP").innerHTML = objPeopleProfile[0].address;
document.getElementById("sexP").innerHTML = objPeopleProfile[0].sex;
document.getElementById("emailP").innerHTML = objPeopleProfile[0].email;
*/

